#!/usr/bin/env python3
# Hardware Monitor - Tkinter GUI
# Cross-platform (Windows/macOS/Linux) using psutil and NVIDIA NVML if available.
# No CLI usage required; double-click start script to run.

import sys
import threading
import time
import platform
import psutil
import tkinter as tk
from tkinter import ttk

# Try NVIDIA NVML (GPU metrics), optional
gpu_supported = False
gpu_error = None
gpu_info_cache = {}
try:
    import pynvml as N
    N.nvmlInit()
    gpu_supported = True
except Exception as e:
    gpu_error = str(e)

APP_TITLE = "Sam's Simple Hardware Monitor"
REFRESH_MS = 1000  # Update interval

def bytes2human(n: float) -> str:
    symbols = ('B','KB','MB','GB','TB','PB')
    i = 0
    while n >= 1024 and i < len(symbols)-1:
        n /= 1024.0
        i += 1
    return f"{n:.1f} {symbols[i]}"

class Section(ttk.LabelFrame):
    def __init__(self, parent, text):
        super().__init__(parent, text=text, padding=8)

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("900x600")
        self.minsize(800, 520)
        try:
            self.iconbitmap(default="")  # safe no-op on non-Windows
        except Exception:
            pass

        # Styles
        style = ttk.Style(self)
        if platform.system() == "Windows":
            style.theme_use("vista")
        elif platform.system() == "Darwin":
            style.theme_use("aqua")
        else:
            # Try a nicer theme if present; fallback to default
            try:
                style.theme_use("clam")
            except Exception:
                pass

        # Layout: use a grid with weight so it resizes nicely
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        container = ttk.Frame(self, padding=10)
        container.grid(row=0, column=0, sticky="nsew")
        for i in range(2):
            container.grid_columnconfigure(i, weight=1)
        for i in range(3):
            container.grid_rowconfigure(i, weight=1)

        # Sections
        self.cpu_section = Section(container, "CPU")
        self.cpu_section.grid(row=0, column=0, sticky="nsew", padx=6, pady=6)
        self.mem_section = Section(container, "Memory")
        self.mem_section.grid(row=0, column=1, sticky="nsew", padx=6, pady=6)
        self.gpu_section = Section(container, "GPU (NVIDIA)")
        self.gpu_section.grid(row=1, column=0, sticky="nsew", padx=6, pady=6)
        self.disk_section = Section(container, "Disk")
        self.disk_section.grid(row=1, column=1, sticky="nsew", padx=6, pady=6)
        self.net_section = Section(container, "Network")
        self.net_section.grid(row=2, column=0, columnspan=2, sticky="nsew", padx=6, pady=6)

        # CPU widgets
        self.cpu_model_var = tk.StringVar(value="")
        ttk.Label(self.cpu_section, textvariable=self.cpu_model_var).grid(row=0, column=0, sticky="w")
        ttk.Separator(self.cpu_section, orient="horizontal").grid(row=1, column=0, sticky="ew", pady=(4,6))
        self.cpu_overall_bar = ttk.Progressbar(self.cpu_section, length=250, maximum=100)
        self.cpu_overall_bar.grid(row=2, column=0, sticky="ew", pady=2)
        self.cpu_overall_label = ttk.Label(self.cpu_section, text="CPU: -- %")
        self.cpu_overall_label.grid(row=3, column=0, sticky="w", pady=(0,6))

        self.core_frame = ttk.Frame(self.cpu_section)
        self.core_frame.grid(row=4, column=0, sticky="nsew")
        self.cpu_section.grid_rowconfigure(4, weight=1)
        self.cpu_section.grid_columnconfigure(0, weight=1)

        # Memory widgets
        self.mem_bar = ttk.Progressbar(self.mem_section, length=250, maximum=100)
        self.mem_bar.grid(row=0, column=0, sticky="ew", pady=2)
        self.mem_label = ttk.Label(self.mem_section, text="--")
        self.mem_label.grid(row=1, column=0, sticky="w")
        ttk.Separator(self.mem_section, orient="horizontal").grid(row=2, column=0, sticky="ew", pady=(6,6))
        self.swap_bar = ttk.Progressbar(self.mem_section, length=250, maximum=100)
        self.swap_bar.grid(row=3, column=0, sticky="ew", pady=2)
        self.swap_label = ttk.Label(self.mem_section, text="--")
        self.swap_label.grid(row=4, column=0, sticky="w")

        # GPU widgets
        self.gpu_text = tk.Text(self.gpu_section, height=8, wrap="word")
        self.gpu_text.grid(row=0, column=0, sticky="nsew")
        self.gpu_section.grid_rowconfigure(0, weight=1)
        self.gpu_section.grid_columnconfigure(0, weight=1)

        # Disk widgets
        self.disk_tree = ttk.Treeview(self.disk_section, columns=("Usage","Read/s","Write/s"), show="headings", height=6)
        self.disk_tree.heading("Usage", text="Usage")
        self.disk_tree.heading("Read/s", text="Read/s")
        self.disk_tree.heading("Write/s", text="Write/s")
        self.disk_tree.column("Usage", width=120, anchor="center")
        self.disk_tree.column("Read/s", width=120, anchor="center")
        self.disk_tree.column("Write/s", width=120, anchor="center")
        self.disk_tree.grid(row=0, column=0, sticky="nsew")
        self.disk_section.grid_rowconfigure(0, weight=1)
        self.disk_section.grid_columnconfigure(0, weight=1)

        # Network widgets
        self.net_tree = ttk.Treeview(self.net_section, columns=("Sent/s","Recv/s","Total Sent","Total Recv"), show="headings", height=6)
        for col, w in (("Sent/s",120),("Recv/s",120),("Total Sent",120),("Total Recv",120)):
            self.net_tree.heading(col, text=col)
            self.net_tree.column(col, width=w, anchor="center")
        self.net_tree.grid(row=0, column=0, sticky="nsew")
        self.net_section.grid_rowconfigure(0, weight=1)
        self.net_section.grid_columnconfigure(0, weight=1)

        # Statusbar
        self.status_var = tk.StringVar(value=f"{platform.system()} {platform.release()} | Python {platform.python_version()} | psutil {psutil.__version__}")
        status = ttk.Label(self, textvariable=self.status_var, relief="sunken", anchor="w", padding=4)
        status.grid(row=1, column=0, sticky="ew")

        # Initialize dynamic structures
        self.core_bars = []
        self.prev_disk = psutil.disk_io_counters(perdisk=True)
        self.prev_net = psutil.net_io_counters(pernic=True)
        self.after(200, self.build_core_bars)
        self.after(500, self.refresh)

        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def build_core_bars(self):
        # Build progress bars for each CPU core
        for w in self.core_frame.winfo_children():
            w.destroy()
        percpu = psutil.cpu_percent(interval=None, percpu=True)
        self.core_bars = []
        for idx, _ in enumerate(percpu):
            row = idx // 4
            col = idx % 4
            frm = ttk.Frame(self.core_frame, padding=(0,2,8,2))
            frm.grid(row=row, column=col, sticky="ew")
            ttk.Label(frm, text=f"Core {idx}").grid(row=0, column=0, sticky="w")
            bar = ttk.Progressbar(frm, length=160, maximum=100)
            bar.grid(row=1, column=0, sticky="ew")
            self.core_bars.append(bar)

    def refresh(self):
        try:
            # CPU
            self.cpu_model_var.set(platform.processor() or platform.machine())
            overall = psutil.cpu_percent(interval=None)
            self.cpu_overall_bar['value'] = overall
            self.cpu_overall_label.config(text=f"CPU: {overall:5.1f} % | {psutil.cpu_freq().current:.0f} MHz" if psutil.cpu_freq() else f"CPU: {overall:5.1f} %")
            for bar, pct in zip(self.core_bars, psutil.cpu_percent(interval=None, percpu=True)):
                bar['value'] = pct

            # Memory
            vm = psutil.virtual_memory()
            self.mem_bar['value'] = vm.percent
            self.mem_label.config(text=f"RAM: {bytes2human(vm.used)} / {bytes2human(vm.total)} ({vm.percent:.0f}%)")
            sw = psutil.swap_memory()
            self.swap_bar['value'] = sw.percent
            self.swap_label.config(text=f"Swap: {bytes2human(sw.used)} / {bytes2human(sw.total)} ({sw.percent:.0f}%)")

            # GPU
            self.update_gpu_text()

            # Disk
            self.update_disks()

            # Network
            self.update_network()

        except Exception as e:
            self.status_var.set(f"Error: {e}")
        finally:
            self.after(REFRESH_MS, self.refresh)

    def update_gpu_text(self):
        self.gpu_text.config(state="normal")
        self.gpu_text.delete("1.0", "end")
        if not gpu_supported:
            self.gpu_text.insert("end", "NVIDIA NVML not available. GPU stats will be skipped.\n")
            if gpu_error:
                self.gpu_text.insert("end", f"Reason: {gpu_error}\n")
            self.gpu_text.config(state="disabled")
            return
        try:
            count = N.nvmlDeviceGetCount()
            if count == 0:
                self.gpu_text.insert("end", "No NVIDIA GPUs detected.\n")
            for i in range(count):
                h = N.nvmlDeviceGetHandleByIndex(i)
                name = N.nvmlDeviceGetName(h).decode()
                util = N.nvmlDeviceGetUtilizationRates(h)
                mem = N.nvmlDeviceGetMemoryInfo(h)
                temp = None
                try:
                    temp = N.nvmlDeviceGetTemperature(h, N.NVML_TEMPERATURE_GPU)
                except Exception:
                    pass
                line = f"GPU {i}: {name}\n  Util: {util.gpu}% | Mem: {mem.used//(1024*1024)}/{mem.total//(1024*1024)} MiB"
                if temp is not None:
                    line += f" | Temp: {temp}°C"
                self.gpu_text.insert("end", line + "\n")
        except Exception as e:
            self.gpu_text.insert("end", f"GPU error: {e}\n")
        self.gpu_text.config(state="disabled")

    def update_disks(self):
        # Compute per-second read/write since last poll
        cur = psutil.disk_io_counters(perdisk=True)
        # Clear tree
        for i in self.disk_tree.get_children():
            self.disk_tree.delete(i)

        # For each mounted partition, show usage and estimated R/W deltas
        mounts = {p.device: p.mountpoint for p in psutil.disk_partitions(all=False) if p.fstype}
        # Map platform-specific device names
        for dev, mount in mounts.items():
            usage = psutil.disk_usage(mount)
            readps = writeps = 0.0
            if dev in self.prev_disk and dev in cur:
                dt_read = max(cur[dev].read_bytes - self.prev_disk[dev].read_bytes, 0)
                dt_write = max(cur[dev].write_bytes - self.prev_disk[dev].write_bytes, 0)
                readps = dt_read / (REFRESH_MS/1000.0)
                writeps = dt_write / (REFRESH_MS/1000.0)
            self.disk_tree.insert("", "end", values=(
                f"{mount} {usage.percent:.0f}% ({bytes2human(usage.used)}/{bytes2human(usage.total)})",
                f"{bytes2human(readps)}/s",
                f"{bytes2human(writeps)}/s"
            ))
        self.prev_disk = cur

    def update_network(self):
        cur = psutil.net_io_counters(pernic=True)
        # Clear tree
        for i in self.net_tree.get_children():
            self.net_tree.delete(i)
        for nic, counters in cur.items():
            if nic not in self.prev_net:
                sentps = recvps = 0.0
            else:
                dt_sent = max(counters.bytes_sent - self.prev_net[nic].bytes_sent, 0)
                dt_recv = max(counters.bytes_recv - self.prev_net[nic].bytes_recv, 0)
                sentps = dt_sent / (REFRESH_MS/1000.0)
                recvps = dt_recv / (REFRESH_MS/1000.0)
            self.net_tree.insert("", "end", values=(
                f"{bytes2human(sentps)}/s",
                f"{bytes2human(recvps)}/s",
                bytes2human(counters.bytes_sent),
                bytes2human(counters.bytes_recv),
            ))
        self.prev_net = cur

    def on_close(self):
        try:
            if gpu_supported:
                N.nvmlShutdown()
        except Exception:
            pass
        self.destroy()

def main():
    app = App()
    app.mainloop()

if __name__ == "__main__":
    main()
